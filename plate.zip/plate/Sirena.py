import requests
from requests.auth import HTTPDigestAuth
import logging
import socket

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Device details
SHELLY_IP = "100.100.100.101"  # Replace with actual IP address
ENDPOINT = f"http://{SHELLY_IP}/rpc/Switch.Set?id=0&on=true"

# Credentials
USERNAME = "admin"  # Replace with actual username
PASSWORD = "16888"  # Replace with actual password

def send_siren_command(timeout=5):
    try:
        # Verificare preventivamente la raggiungibilità dell'host
        socket.create_connection((SHELLY_IP, 80), timeout=timeout)
        
        # Impostare un timeout per la richiesta
        response = requests.get(
            ENDPOINT, 
            auth=HTTPDigestAuth(USERNAME, PASSWORD),
            timeout=timeout
        )

        # Registrare e verificare la risposta
        logger.info(f"Siren Status Code: {response.status_code}")
        logger.info(f"Siren Response Body: {response.text}")

        # Sollevare un'eccezione in caso di errore
        response.raise_for_status()

    except socket.timeout:
        logger.error(f"Timeout: Host {SHELLY_IP} non raggiungibile")
        raise ConnectionError(f"Host {SHELLY_IP} non raggiungibile (timeout)")
    
    except socket.error as e:
        logger.error(f"Errore di rete: {e}")
        raise ConnectionError(f"Errore di rete con {SHELLY_IP}: {e}")
    
    except requests.exceptions.RequestException as e:
        logger.error(f"Errore nella richiesta: {e}")
        raise ConnectionError(f"Errore durante la richiesta a {SHELLY_IP}: {e}")
    
    except Exception as e:
        logger.error(f"Errore imprevisto: {e}")
        raise

def activate_siren():
    # Questo metodo mantiene la compatibilità con le chiamate esistenti
    send_siren_command()