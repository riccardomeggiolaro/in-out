import tkinter as tk
from tkinter import messagebox
import logging
import traceback

# Import the local modules
import PannelloLED
import Sirena

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(levelname)s - %(message)s',
                    filename='app_log.txt',
                    filemode='a')
logger = logging.getLogger(__name__)

def send_message():
    text = entry.get().strip()
    if not text:
        messagebox.showerror("Errore", "Stringa vuota")
        return
    try:
        # Send message to LED panel
        PannelloLED.send_message("100.100.100.100", text)
        
        # Activate siren
        Sirena.send_siren_command()
        
        messagebox.showinfo("Successo", "Messaggio inviato con successo!")
    except Exception as e:
        logger.error(f"Errore nell'invio: {e}")
        logger.error(traceback.format_exc())
        try:
            messagebox.showerror("Errore", f"Errore nell'invio: {e}")
        except Exception:
            # Fallback error handling if messagebox fails
            print(f"Errore nell'invio: {e}")

def activate_siren():
    try:
        Sirena.send_siren_command()
        messagebox.showinfo("Successo", "Sirena attivata!")
    except Exception as e:
        logger.error(f"Errore nell'attivazione: {e}")
        logger.error(traceback.format_exc())
        try:
            messagebox.showerror("Errore", f"Errore nell'attivazione: {e}")
        except Exception:
            # Fallback error handling if messagebox fails
            print(f"Errore nell'attivazione: {e}")

# GUI setup
root = tk.Tk()
root.title("Controllo LED e Sirena")

frame = tk.Frame(root, padx=20, pady=20)
frame.pack()

entry = tk.Entry(frame, width=30)
entry.pack(pady=5)

btn_send = tk.Button(frame, text="Invia", command=send_message)
btn_send.pack(side=tk.LEFT, padx=5)

btn_siren = tk.Button(frame, text="Suona sirena", command=activate_siren)
btn_siren.pack(side=tk.RIGHT, padx=5)

root.mainloop()